Please Read YanivAnava066539347.PDF
When completed Go to ILDM folder
Go to LawViewer folder
Go to bin folder
Go to Debug folder
Run ILDM.exe
Use ILDM Israeli Law Data Miner system
Thank you 