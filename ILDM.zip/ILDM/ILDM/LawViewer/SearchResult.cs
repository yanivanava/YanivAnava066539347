﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LawViewer
{
    public class SearchResult
    {
        public string LawDetails { get; set; }
        public List<int> ChartValue { get; set; } = new List<int>();
        public string ListOfFixes { get; set; }
    }
}
