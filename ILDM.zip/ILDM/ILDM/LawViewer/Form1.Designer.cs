﻿namespace LawViewer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.gb1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_LoadData = new System.Windows.Forms.Button();
            this.txt_Url = new System.Windows.Forms.TextBox();
            this.lbl_DataSource = new System.Windows.Forms.Label();
            this.gb2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_LawPerYear = new System.Windows.Forms.Button();
            this.btn_DifferenceBetweenLaws = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.gb3 = new System.Windows.Forms.GroupBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.txt_TypeLaw = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_LawDetails = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Previous_gb3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_fixes = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_Amount = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_Amount = new System.Windows.Forms.Button();
            this.txt_ListOfLaws_p2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_FromTo = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_fromYear = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_ToYear = new System.Windows.Forms.TextBox();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label12 = new System.Windows.Forms.Label();
            this.gb1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.gb2.SuspendLayout();
            this.gb3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // gb1
            // 
            this.gb1.Controls.Add(this.pictureBox1);
            this.gb1.Controls.Add(this.label1);
            this.gb1.Controls.Add(this.btn_LoadData);
            this.gb1.Controls.Add(this.txt_Url);
            this.gb1.Controls.Add(this.lbl_DataSource);
            this.gb1.Location = new System.Drawing.Point(12, 2);
            this.gb1.Name = "gb1";
            this.gb1.Size = new System.Drawing.Size(1115, 659);
            this.gb1.TabIndex = 0;
            this.gb1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(389, 245);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(254, 313);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(843, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 22);
            this.label1.TabIndex = 3;
            // 
            // btn_LoadData
            // 
            this.btn_LoadData.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LoadData.Location = new System.Drawing.Point(432, 134);
            this.btn_LoadData.Name = "btn_LoadData";
            this.btn_LoadData.Size = new System.Drawing.Size(168, 29);
            this.btn_LoadData.TabIndex = 2;
            this.btn_LoadData.Text = "טען נתונים";
            this.btn_LoadData.UseVisualStyleBackColor = true;
            this.btn_LoadData.Click += new System.EventHandler(this.btn_LoadData_Click);
            // 
            // txt_Url
            // 
            this.txt_Url.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Url.Location = new System.Drawing.Point(194, 83);
            this.txt_Url.Name = "txt_Url";
            this.txt_Url.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_Url.Size = new System.Drawing.Size(623, 26);
            this.txt_Url.TabIndex = 1;
            this.txt_Url.Text = "https://www.odata.org.il/organization/freedom-of-information-israel";
            // 
            // lbl_DataSource
            // 
            this.lbl_DataSource.AutoSize = true;
            this.lbl_DataSource.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DataSource.Location = new System.Drawing.Point(823, 84);
            this.lbl_DataSource.Name = "lbl_DataSource";
            this.lbl_DataSource.Size = new System.Drawing.Size(83, 22);
            this.lbl_DataSource.TabIndex = 0;
            this.lbl_DataSource.Text = "אתר מקור:";
            this.lbl_DataSource.Click += new System.EventHandler(this.lbl_DataSource_Click);
            // 
            // gb2
            // 
            this.gb2.Controls.Add(this.button3);
            this.gb2.Controls.Add(this.btn_LawPerYear);
            this.gb2.Controls.Add(this.btn_DifferenceBetweenLaws);
            this.gb2.Controls.Add(this.label4);
            this.gb2.Location = new System.Drawing.Point(21, 12);
            this.gb2.Name = "gb2";
            this.gb2.Size = new System.Drawing.Size(1115, 650);
            this.gb2.TabIndex = 1;
            this.gb2.TabStop = false;
            this.gb2.Visible = false;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Ink Free", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(74, 253);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(240, 169);
            this.button3.TabIndex = 12;
            this.button3.Text = "כמות תיקוני חוק לאורך השנים";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_LawPerYear
            // 
            this.btn_LawPerYear.Font = new System.Drawing.Font("Ink Free", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LawPerYear.Location = new System.Drawing.Point(432, 253);
            this.btn_LawPerYear.Name = "btn_LawPerYear";
            this.btn_LawPerYear.Size = new System.Drawing.Size(240, 169);
            this.btn_LawPerYear.TabIndex = 11;
            this.btn_LawPerYear.Text = "כמות תיקוני חוק לפי שנה";
            this.btn_LawPerYear.UseVisualStyleBackColor = true;
            this.btn_LawPerYear.Click += new System.EventHandler(this.btn_LawPerYear_Click);
            // 
            // btn_DifferenceBetweenLaws
            // 
            this.btn_DifferenceBetweenLaws.Font = new System.Drawing.Font("Ink Free", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DifferenceBetweenLaws.Location = new System.Drawing.Point(794, 253);
            this.btn_DifferenceBetweenLaws.Name = "btn_DifferenceBetweenLaws";
            this.btn_DifferenceBetweenLaws.Size = new System.Drawing.Size(240, 169);
            this.btn_DifferenceBetweenLaws.TabIndex = 10;
            this.btn_DifferenceBetweenLaws.Text = "הפרש בין תיקוני החוק";
            this.btn_DifferenceBetweenLaws.UseVisualStyleBackColor = true;
            this.btn_DifferenceBetweenLaws.Click += new System.EventHandler(this.btn_DifferenceBetweenLaws_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Kristen ITC", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(827, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(229, 40);
            this.label4.TabIndex = 4;
            this.label4.Text = "בחר/י דוח להצגה:";
            // 
            // gb3
            // 
            this.gb3.Controls.Add(this.panel3);
            this.gb3.Controls.Add(this.panel2);
            this.gb3.Controls.Add(this.button2);
            this.gb3.Controls.Add(this.button1);
            this.gb3.Controls.Add(this.btn_Previous_gb3);
            this.gb3.Controls.Add(this.label3);
            this.gb3.Controls.Add(this.panel1);
            this.gb3.Controls.Add(this.btn_Search);
            this.gb3.Controls.Add(this.txt_TypeLaw);
            this.gb3.Location = new System.Drawing.Point(18, 5);
            this.gb3.Name = "gb3";
            this.gb3.Size = new System.Drawing.Size(1124, 650);
            this.gb3.TabIndex = 2;
            this.gb3.TabStop = false;
            this.gb3.Visible = false;
            // 
            // btn_Search
            // 
            this.btn_Search.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_Search.Location = new System.Drawing.Point(247, 34);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(90, 27);
            this.btn_Search.TabIndex = 1;
            this.btn_Search.Text = "חפש";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // txt_TypeLaw
            // 
            this.txt_TypeLaw.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_TypeLaw.ForeColor = System.Drawing.Color.Blue;
            this.txt_TypeLaw.Location = new System.Drawing.Point(353, 34);
            this.txt_TypeLaw.Name = "txt_TypeLaw";
            this.txt_TypeLaw.Size = new System.Drawing.Size(363, 27);
            this.txt_TypeLaw.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(722, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "הזן חוק או חלק ממנו:";
            // 
            // chart1
            // 
            chartArea4.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chart1.Legends.Add(legend4);
            this.chart1.Location = new System.Drawing.Point(14, 72);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(678, 442);
            this.chart1.TabIndex = 4;
            this.chart1.Text = "chart1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(252, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(238, 23);
            this.label5.TabIndex = 5;
            this.label5.Text = "הפרש בין תיקוני החוק (חודשים)";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txt_fixes);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txt_LawDetails);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.chart1);
            this.panel1.Location = new System.Drawing.Point(24, 99);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1082, 520);
            this.panel1.TabIndex = 6;
            this.panel1.Visible = false;
            // 
            // txt_LawDetails
            // 
            this.txt_LawDetails.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_LawDetails.Location = new System.Drawing.Point(734, 46);
            this.txt_LawDetails.Multiline = true;
            this.txt_LawDetails.Name = "txt_LawDetails";
            this.txt_LawDetails.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_LawDetails.Size = new System.Drawing.Size(332, 203);
            this.txt_LawDetails.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(1001, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "ת.ז חוק:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btn_Previous_gb3
            // 
            this.btn_Previous_gb3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_Previous_gb3.Location = new System.Drawing.Point(1025, 608);
            this.btn_Previous_gb3.Name = "btn_Previous_gb3";
            this.btn_Previous_gb3.Size = new System.Drawing.Size(90, 27);
            this.btn_Previous_gb3.TabIndex = 7;
            this.btn_Previous_gb3.Text = "הקודם";
            this.btn_Previous_gb3.UseVisualStyleBackColor = true;
            this.btn_Previous_gb3.Click += new System.EventHandler(this.btn_Previous_gb3_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button1.Location = new System.Drawing.Point(137, 35);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 27);
            this.button1.TabIndex = 8;
            this.button1.Text = "נקה";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button2.Location = new System.Drawing.Point(12, 608);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 27);
            this.button2.TabIndex = 9;
            this.button2.Text = "סיום";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(968, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 23);
            this.label6.TabIndex = 9;
            this.label6.Text = "תיקוני החוק:";
            // 
            // txt_fixes
            // 
            this.txt_fixes.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_fixes.Location = new System.Drawing.Point(734, 300);
            this.txt_fixes.Multiline = true;
            this.txt_fixes.Name = "txt_fixes";
            this.txt_fixes.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_fixes.Size = new System.Drawing.Size(332, 203);
            this.txt_fixes.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chart2);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txt_ListOfLaws_p2);
            this.panel2.Controls.Add(this.btn_Amount);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txt_Amount);
            this.panel2.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.panel2.Location = new System.Drawing.Point(27, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1082, 588);
            this.panel2.TabIndex = 10;
            this.panel2.Visible = false;
            // 
            // txt_Amount
            // 
            this.txt_Amount.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_Amount.ForeColor = System.Drawing.Color.Blue;
            this.txt_Amount.Location = new System.Drawing.Point(833, 105);
            this.txt_Amount.Name = "txt_Amount";
            this.txt_Amount.Size = new System.Drawing.Size(162, 27);
            this.txt_Amount.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label7.Location = new System.Drawing.Point(1001, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 19);
            this.label7.TabIndex = 6;
            this.label7.Text = "בחר שנה:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label8.Location = new System.Drawing.Point(248, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(568, 59);
            this.label8.TabIndex = 7;
            this.label8.Text = "כמות החוקים שתוקנו לפי שנה";
            // 
            // btn_Amount
            // 
            this.btn_Amount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_Amount.Location = new System.Drawing.Point(715, 105);
            this.btn_Amount.Name = "btn_Amount";
            this.btn_Amount.Size = new System.Drawing.Size(90, 27);
            this.btn_Amount.TabIndex = 8;
            this.btn_Amount.Text = "חפש";
            this.btn_Amount.UseVisualStyleBackColor = true;
            this.btn_Amount.Click += new System.EventHandler(this.btn_Amount_Click);
            // 
            // txt_ListOfLaws_p2
            // 
            this.txt_ListOfLaws_p2.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_ListOfLaws_p2.ForeColor = System.Drawing.Color.Blue;
            this.txt_ListOfLaws_p2.Location = new System.Drawing.Point(698, 196);
            this.txt_ListOfLaws_p2.Multiline = true;
            this.txt_ListOfLaws_p2.Name = "txt_ListOfLaws_p2";
            this.txt_ListOfLaws_p2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_ListOfLaws_p2.Size = new System.Drawing.Size(366, 357);
            this.txt_ListOfLaws_p2.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label9.Location = new System.Drawing.Point(945, 170);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 23);
            this.label9.TabIndex = 10;
            this.label9.Text = "רשימת החוקים:";
            // 
            // chart2
            // 
            chartArea5.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chart2.Legends.Add(legend5);
            this.chart2.Location = new System.Drawing.Point(90, 238);
            this.chart2.Name = "chart2";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart2.Series.Add(series2);
            this.chart2.Size = new System.Drawing.Size(500, 300);
            this.chart2.TabIndex = 11;
            this.chart2.Text = "chart2";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.chart3);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.txt_ToYear);
            this.panel3.Controls.Add(this.btn_FromTo);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txt_fromYear);
            this.panel3.Location = new System.Drawing.Point(24, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1076, 592);
            this.panel3.TabIndex = 3;
            this.panel3.Visible = false;
            // 
            // btn_FromTo
            // 
            this.btn_FromTo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_FromTo.Location = new System.Drawing.Point(444, 98);
            this.btn_FromTo.Name = "btn_FromTo";
            this.btn_FromTo.Size = new System.Drawing.Size(90, 27);
            this.btn_FromTo.TabIndex = 11;
            this.btn_FromTo.Text = "חפש";
            this.btn_FromTo.UseVisualStyleBackColor = true;
            this.btn_FromTo.Click += new System.EventHandler(this.btn_FromTo_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label10.Location = new System.Drawing.Point(965, 100);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 19);
            this.label10.TabIndex = 10;
            this.label10.Text = "החל מ:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // txt_fromYear
            // 
            this.txt_fromYear.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_fromYear.ForeColor = System.Drawing.Color.Blue;
            this.txt_fromYear.Location = new System.Drawing.Point(797, 98);
            this.txt_fromYear.Name = "txt_fromYear";
            this.txt_fromYear.Size = new System.Drawing.Size(162, 27);
            this.txt_fromYear.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label11.Location = new System.Drawing.Point(745, 100);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 19);
            this.label11.TabIndex = 13;
            this.label11.Text = "עד:";
            // 
            // txt_ToYear
            // 
            this.txt_ToYear.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_ToYear.ForeColor = System.Drawing.Color.Blue;
            this.txt_ToYear.Location = new System.Drawing.Point(577, 97);
            this.txt_ToYear.Name = "txt_ToYear";
            this.txt_ToYear.Size = new System.Drawing.Size(162, 27);
            this.txt_ToYear.TabIndex = 12;
            // 
            // chart3
            // 
            chartArea6.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.chart3.Legends.Add(legend6);
            this.chart3.Location = new System.Drawing.Point(100, 177);
            this.chart3.Name = "chart3";
            this.chart3.Size = new System.Drawing.Size(882, 395);
            this.chart3.TabIndex = 14;
            this.chart3.Text = "chart3";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label12.Location = new System.Drawing.Point(292, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(455, 59);
            this.label12.TabIndex = 8;
            this.label12.Text = "תיקוני חוק לאורך השנים";
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1148, 675);
            this.Controls.Add(this.gb3);
            this.Controls.Add(this.gb2);
            this.Controls.Add(this.gb1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Israely Law Data Miner";
            this.gb1.ResumeLayout(false);
            this.gb1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.gb2.ResumeLayout(false);
            this.gb2.PerformLayout();
            this.gb3.ResumeLayout(false);
            this.gb3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb1;
        private System.Windows.Forms.Button btn_LoadData;
        private System.Windows.Forms.TextBox txt_Url;
        private System.Windows.Forms.Label lbl_DataSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox gb2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_DifferenceBetweenLaws;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_LawPerYear;
        private System.Windows.Forms.GroupBox gb3;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox txt_TypeLaw;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txt_LawDetails;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Previous_gb3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_fixes;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_ListOfLaws_p2;
        private System.Windows.Forms.Button btn_Amount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Amount;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_ToYear;
        private System.Windows.Forms.Button btn_FromTo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_fromYear;
    }
}

