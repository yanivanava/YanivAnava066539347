﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LawViewer
{
    public class Law
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string LawSource { get; set; }
        public string LawSubSource { get; set; }
        public string OfficialName { get; set; }
        public string NormalizeName { get; set; }
        public string KnessetUrl { get; set; }
        public IList<string> RecentOfficialNames { get; set; }
        public string PublicationDate { get; set; }
        public string Uri { get; set; }
        public HalahotName HalahotName { get; set; }
        public TnufaName TnufaName { get; set; }
        //public string KahamName { get; set; }
        public OpenLawBook OpenLawBook { get; set; }
    }

    public class HalahotName
    {
        public string Name { get; set; }
        public string Score { get; set; }
    }

    public class TnufaName
    {
        public string Name { get; set; }
        public string Score { get; set; }
    }

    public class OpenLawBook
    {
        public string OpenLawBookName { get; set; }
        public string OpenLawBookUrl { get; set; }
        public string OpenLawBookUri { get; set; }
        public string OpenLawBookNameInNamesList { get; set; }
        public string OpenLawBookInLawHeader { get; set; }
        public string WikiHref { get; set; }
    }
}
