﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static LawViewer.RequestType;

namespace LawViewer
{
    public class DataEngine
    {
        private readonly List<Law> m_Laws;
        public DataEngine(List<Law> laws)
        {
            m_Laws = laws;
        }

        public SearchResult ExecuteAlgorithm(RequestType requestType, string lawName,string year = "")
        {
            switch (requestType)
            {
                case DifferenceBetweenLaws:
                    return GetDifferenceBetweenFixes(lawName);
                case AmountOfFixesPerYear:
                    return GetAmountOfFixesPerYear(year);
            }

            return null;
        }

        public SearchResult GetAmountOfFixesPerYear(string year)
        {
            var result = new SearchResult();
            var allLaws = m_Laws.Where(l => DateTime.Parse(l.PublicationDate).Year.ToString() == year).ToList();

            var fixesLaws = allLaws.Where(l => l.OfficialName.Contains("תיקון")).ToList();
            result.ListOfFixes = GetFixesList(fixesLaws).ToString();
            result.ChartValue.Add(fixesLaws.Count);
            return result;
        }


        private SearchResult GetDifferenceBetweenFixes(string lawName)
        { 
            var relevantLaws = m_Laws.Where(law => law.OfficialName.Contains(lawName)).ToList();

            if (relevantLaws.Count <= 0)
            {
                MessageBox.Show($"חוק '{lawName}' לא נמצא במאגר הנתונים", "שגיאה");
                return null;
            }

            var result = new SearchResult();

            var primaryLaw = FindPrimaryLaw(relevantLaws);

            var sortedLaws = SortByYears(relevantLaws);

            result.LawDetails = GetLawDetails(primaryLaw);

            result.ListOfFixes = GetFixesList(sortedLaws).ToString();

            result.ChartValue = CalculateDifference(sortedLaws);
            
            return result;
        }

        private static List<int> CalculateDifference(List<Law> sortedLaws)
        {
            var listOfDiff = new List<int>();

            for (var i = 1; i < sortedLaws.Count; i++)
            {
                var diff = Math.Abs((DateTime.Parse(sortedLaws[i].PublicationDate) -
                                     DateTime.Parse(sortedLaws[i - 1].PublicationDate)).Days / 30);
                listOfDiff.Add(diff);
            }

            return listOfDiff;
        }

        private static StringBuilder GetFixesList(List<Law> sortedLaws)
        {
            var sb = new StringBuilder();

            foreach (var law in sortedLaws)
            {
                sb.AppendLine(law.OfficialName);
            }

            return sb;
        }

        private static List<Law> SortByYears(List<Law> relevantLaws)
        {
            List<Law> lawsSorted = new List<Law>();
            var years = relevantLaws.Select(law => DateTime.Parse(law?.PublicationDate).Year).ToList();
            var yearsSorted = years.OrderBy(number => number).ToList();
            foreach (var year in yearsSorted)
            {
                foreach (var law in relevantLaws)
                {
                    if (DateTime.Parse(law.PublicationDate).Year == year)
                    {
                        if (!lawsSorted.Contains(law))
                        {
                            lawsSorted.Add(law);
                        }
                       
                    }
                }
            }

            return lawsSorted;
        }

        private string GetLawDetails(Law law)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"מספר מזהה: {law?.Id}");
            sb.AppendLine($"שם רישמי: {law?.OfficialName}");
            sb.AppendLine($"שם מנורמל: {law?.NormalizeName}");
            sb.AppendLine($"תאריך פרסום: {law?.PublicationDate}");
            sb.AppendLine($"סוג: {law?.Type}");
            sb.AppendLine($"מקור: {law?.LawSource}");
            sb.AppendLine($"מקור משנה: {law?.LawSubSource}");
            return sb.ToString();
        }
        private static Law FindPrimaryLaw(List<Law> laws)
        {
            var primary = laws.Where(l => !l.OfficialName.Contains("תיקון"));
            var count = primary.Count();
            return primary?.FirstOrDefault();
        }

    }
}
