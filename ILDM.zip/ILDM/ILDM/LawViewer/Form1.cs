﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace LawViewer
{
    public partial class Form1 : Form
    {
        private DataImporter m_DataImporter;
        private DataEngine m_DataEngine;
        private RequestType m_RequestType;
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_DataSource_Click(object sender, EventArgs e)
        {

        }

        private void btn_LoadData_Click(object sender, EventArgs e)
        {
            gb1.Visible = false;
            gb2.Visible = true;
            Init(txt_Url.Text);
        }

        private void Init(string url)
        {
            m_DataImporter = new DataImporter(url);
            var laws = m_DataImporter.GetLaws();
            m_DataEngine = new DataEngine(laws);
        }

        private void btn_DifferenceBetweenLaws_Click(object sender, EventArgs e)
        {
            gb2.Visible = false;
            gb3.Visible = true;
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            m_RequestType = RequestType.DifferenceBetweenLaws;
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(txt_TypeLaw.Text))
            {
                MessageBox.Show("שם חוק לא תקין","שגיאה");
                return;
            }

            panel1.Visible = true;

            
            switch (m_RequestType)
            {
                case RequestType.DifferenceBetweenLaws:
                {
                    var result = m_DataEngine.ExecuteAlgorithm(m_RequestType, txt_TypeLaw.Text);
                    txt_LawDetails.Text = result?.LawDetails;
                    txt_fixes.Text = result?.ListOfFixes;
                    chart1.Series.Clear();
                    chart1.Series.Add("Difference between fixes");

                    for (int i = 1; i < result?.ChartValue.Count; i++)
                    {
                        var x = i;
                        var y = result.ChartValue[i - 1];
                        var point = new Point(x, y);
                        var p = chart1.Series["Difference between fixes"].Points.AddXY(x, y);
                        chart1.Series["Difference between fixes"].Points[p].Label = y.ToString();
                    }

                    break;
                }
                case RequestType.AmountOfFixesPerYear:
                {
                    var year = txt_Amount.Text;
                    var result = m_DataEngine.ExecuteAlgorithm(m_RequestType, txt_TypeLaw.Text, year);
                    txt_ListOfLaws_p2.Text = result.ListOfFixes;
                    chart2.Series.Clear();
                    chart2.Series.Add("List of fixes per year");
                    var x = year;
                    var y = result.ChartValue[0];
                    var p = chart1.Series["List of fixes per year"].Points.AddXY(x, y);
                    chart1.Series["List of fixes per year"].Points[p].Label = y.ToString();
                }
                    break;
            }
            

            btn_Search.Enabled = false;
        }

        private void btn_LawPerYear_Click(object sender, EventArgs e)
        {
            gb2.Visible = false;
            gb3.Visible = true;
            m_RequestType = RequestType.AmountOfFixesPerYear;
            panel1.Visible = false;
            panel2.Visible = true;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_Previous_gb3_Click(object sender, EventArgs e)
        {
            gb3.Visible = false;
            gb2.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt_TypeLaw.Text = "";
            txt_LawDetails.Text = "";
            btn_Search.Enabled = true;
            panel1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Amount_Click(object sender, EventArgs e)
        {
            var year = txt_Amount.Text;
            var result = m_DataEngine.ExecuteAlgorithm(m_RequestType, txt_TypeLaw.Text, year);
            txt_ListOfLaws_p2.Text = result.ListOfFixes;
            chart2.Series.Clear();
            chart2.Series.Add("List of fixes per year");
            var x = year;
            var y = result.ChartValue[0];
            var p = chart2.Series["List of fixes per year"].Points.AddXY(x, y);
            chart2.Series["List of fixes per year"].Points[p].Label = y.ToString();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void btn_FromTo_Click(object sender, EventArgs e)
        {
            var from =Convert.ToInt32(txt_fromYear.Text);
            var to = Convert.ToInt32(txt_ToYear.Text);
            chart3.Series.Add("Amount of fixes per year");
            for (int i = from; i < to; i++)
            {
                var result = m_DataEngine.GetAmountOfFixesPerYear(i.ToString());
                var x = i;
                var y = result.ChartValue[0];
                var p = chart3.Series["Amount of fixes per year"].Points.AddXY(x, y);
                chart3.Series["Amount of fixes per year"].Points[p].Label = y.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            gb2.Visible = false;
            gb3.Visible = true;
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = true;
        }
    }
}
