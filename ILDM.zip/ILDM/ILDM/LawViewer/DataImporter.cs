﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace LawViewer
{
    public class DataImporter
    {
        private List<Law> m_Laws;

        public DataImporter(string url)
        {
            if (!GetDataFromSite(url))
            {
                LoadFromFile();
            }
        }

        public List<Law> GetLaws()
        {
            return m_Laws;
        }

        private bool GetDataFromSite(string url)
        {
              //TODO: need to implement http client to get data from Kneset site
              return false;
        }

        private void LoadFromFile()
        {
            var jsonString = File.ReadAllText(@"Laws\Laws.json");
            m_Laws = JsonConvert.DeserializeObject<Law[]>(jsonString).ToList();
        }
    }
}
